<!DOCTYPE html>
<html>
    <head>
        <title>E-Store</title>
        <!--latest compiled and minified CSS-->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!--jQuery library-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified javascript-->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content=""width=device-width, initial-scale=1">
            
    </head>
    <body>
      
        
        <div class="container">
            
            
            <div class="panel-body">
                <form method="POST" action="upload.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="user">Username</label>
                        <input type="text" class="form-control" id="user" name="username">
                    </div>
                    <div class="form-group">
                        <label for="file">Profile Pic</label>
                        <input type="file" class="form-control" id="file" name="file">
                    </div>
                    
                    <input type="submit" name="submit" class="btn btn-success" value="submit">
                </form>
            </div>
        </div>
        
        
        
    		
        		
		
	
		
    </body>
</html>

