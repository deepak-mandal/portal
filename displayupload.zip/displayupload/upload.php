<!DOCTYPE html>
<html>
    <head>
        <title>E-Store</title>
        <!--latest compiled and minified CSS-->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!--jQuery library-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified javascript-->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content=""width=device-width, initial-scale=1">
            
    </head>
    <body>
      
        
        <div class="container">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    
                    <thead>
                       
                            <th>id</th>
                            <th>username  </th>
                            <th>pic</th>
                       
                        
                    </thead>
                    
                    
                    
                    <tbody>
                    
                    
                    <?php
                    
                    $con=mysqli_connect('localhost', 'root');
                    mysqli_select_db($con, 'displayupload');
                    
                    
                    if(isset($_POST['submit'])){
                    $username=$_POST['username'];
                    $files= $_FILES['file'];
                    
                    print_r($username);
                    echo "<br>";
                    //print_r($files);
                    
                    $filename=$files['name'];
                    //print_r($filename);
                    $fileerror=$files['error'];
                    $filetmp=$files['tmp_name'];
                    
                    $fileext=explode('.',$filename);
                    $filecheck=strtolower(end($fileext));
                    
                    $fileextstored=array('png', 'jpg', 'jpeg');
                    
                    if(in_array($filecheck,$fileextstored)){
                    
                    $destinationfile='uplaod/'.$filename;
                    move_uploaded_file($filetmp,$destinationfile);
                    
                    $q = "INSERT INTO `imgupload`( `username`, `image`) VALUES ('$username','$destinationfile')";
                    
                    $query=mysqli_query($con,$q);
                    
                    $displayquery="select * from imgupload";
                    $querydisplay=mysqli_query($con,$displayquery);
                    
                    //$row=mysqli_num_rows($querydisplay);
                    
                    while($result=mysqli_fetch_array($querydisplay)){
                    ?>
                    
                    
                    <tr>
                            <td><?php echo $result['id']; ?></td>
                            <td><?php echo $result['username']; ?></td>
                            <td> <img src="<?php echo $result['image']; ?>" height="100px" width="100px"></td>
                            
                    </tr>
                    
                    <?php
                    
                    }
                    
                    
                    
                    }
                    
                    
                    
                    
                    
                    
                    }
                    
                    
                    
                    
                    ?>
                        
                        
                        
                        
                    </tbody>
                </table>
            </div>
        </div>
        
    		
        		
		
	
		
    </body>
</html>

